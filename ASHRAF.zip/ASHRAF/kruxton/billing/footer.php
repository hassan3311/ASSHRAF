<footer class="custom-footer">
    <div class="container text-center">
        <p class="mb-0">© <?php echo date("Y"); ?> Hassan Chandia. All Rights Reserved.</p>
    </div>
</footer>
<style>.custom-footer {
    position: fixed;
    left: 0;
    bottom: 0;
    width: 100%;
    background: #1e85ff; /* 👈 apna color rakh sakte ho */
    color: #fff;
    text-align: center;
    padding: 10px 0;
    font-size: 14px;
    border-top: 3px solid #00e2fa;
    z-index: 999;
}
.custom-footer p {
    margin: 0;
}</style>

