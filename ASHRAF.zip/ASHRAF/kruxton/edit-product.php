<?php include('db_connect.php'); ?>

<div class="container-fluid">
    <div class="col-lg-12">
        <div class="row">
            
            <!-- FORM Panel -->
            <div class="col-md-4">
                <form action="" id="manage-product">
                    <div class="card">
                        <div class="card-header">
                            <b>Edit / Add Product</b>
                        </div>
                        <div class="card-body">
                            <!-- Hidden ID -->
                            <input type="hidden" name="id">

                            <div class="form-group">
                                <label class="control-label">Name</label>
                                <input type="text" class="form-control" name="name" required>
                            </div>

                            <div class="form-group">
                                <label class="control-label">Description</label>
                                <textarea name="description" cols="30" rows="4" class="form-control" required></textarea>
                            </div>

                            <div class="form-group">
                                <label class="control-label">Price</label>
                                <input type="number" class="form-control text-right" name="price" required>
                            </div>
                        </div>
                        <div class="card-footer text-center">
                            <button class="btn btn-primary">Save</button>
                            <button class="btn btn-default" type="button" onclick="$('#manage-product').get(0).reset()">Cancel</button>
                        </div>
                    </div>
                </form>
            </div>
            <!-- FORM Panel -->

            <!-- TABLE Panel -->
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">
                        <b>Product List</b>
                    </div>
                    <div class="card-body">
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th width="5%">ID</th>
                                    <th width="20%">Name</th>
                                    <th width="35%">Description</th>
                                    <th width="15%">Price</th>
                                    <th width="25%">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $qry = $conn->query("SELECT * FROM products");
                                while($row = $qry->fetch_assoc()):
                                ?>
                                <tr>
                                    <td><?php echo $row['id'] ?></td>
                                    <td><?php echo $row['name'] ?></td>
                                    <td><?php echo $row['description'] ?></td>
                                    <td><?php echo $row['price'] ?></td>
                                    <td>
                                        <!-- Edit Button -->
                                        <a href="javascript:void(0)" 
                                           class="btn btn-primary btn-sm edit_product"
                                           data-id="<?php echo $row['id'] ?>"
                                           data-name="<?php echo htmlspecialchars($row['name']) ?>"
                                           data-description="<?php echo htmlspecialchars($row['description']) ?>"
                                           data-price="<?php echo $row['price'] ?>">
                                           <i class="fa fa-edit"></i> Edit
                                        </a>

                                        <!-- Delete Button -->
                                        <button class="btn btn-danger btn-sm delete_product" 
                                                type="button" 
                                                data-id="<?php echo $row['id'] ?>">
                                            <i class="fa fa-trash-alt"></i> Delete
                                        </button>
                                    </td>
                                </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <!-- TABLE Panel -->
        </div>
    </div>
</div>

<style>
    td {
        vertical-align: middle !important;
    }
    td p {
        margin: unset;
    }
</style>

<script>
    // Form reset hone par hidden fields clear
    $('#manage-product').on('reset',function(){
        $('input:hidden').val('')
    })

    // Save Product via AJAX
    $('#manage-product').submit(function(e){
        e.preventDefault()
        $.ajax({
            url:'ajax.php?action=save_product',
            data: new FormData($(this)[0]),
            cache: false,
            contentType: false,
            processData: false,
            method: 'POST',
            type: 'POST',
            success:function(resp){
                if(resp==1){
                    alert("Data successfully added")
                    setTimeout(function(){
                        location.reload()
                    },1000)
                }
                else if(resp==2){
                    alert("Data successfully updated")
                    setTimeout(function(){
                        location.reload()
                    },1000)
                }
            }
        })
    })

    // Edit button click → fill form
    $('.edit_product').click(function(){
        var form = $('#manage-product')
        form.get(0).reset() // reset form

        form.find("[name='id']").val($(this).data('id'))
        form.find("[name='name']").val($(this).data('name'))
        form.find("[name='description']").val($(this).data('description'))
        form.find("[name='price']").val($(this).data('price'))
    })
    document.addEventListener("DOMContentLoaded", function() {
    let mayuriFooter = document.querySelector("div div a[href*='mayurik']");
    if (mayuriFooter) {
        mayuriFooter.closest("div").style.display = "none";
    }
});
</script>
