<?php include('db_connect.php');?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product Management System</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js"></script>
    <style>
        body { background-color: #f8f9fa; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; }
        .card { box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.15); border: none; border-radius: 10px; margin-bottom: 20px; }
        .card-header { background: linear-gradient(45deg, #007bff, #0056b3); color: white; border-radius: 10px 10px 0 0 !important; }
        .btn-primary { background: linear-gradient(45deg, #007bff, #0056b3); border: none; }
        .btn-primary:hover { background: linear-gradient(45deg, #0056b3, #004494); }
        .qrcode-container { display: flex; justify-content: center; padding: 15px; background: #f8f9fa; border-radius: 5px; margin-top: 10px; }
        .action-buttons .btn { margin-right: 5px; }
        #productTable { box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.1); }
        .table thead th { background-color: #007bff; color: white; border: none; }
        .modal-content { border-radius: 10px; }
        .modal-header { background: linear-gradient(45deg, #007bff, #0056b3); color: white; border-radius: 10px 10px 0 0; }
        #scanner-container { width: 100%; height: 300px; background-color: #000; margin-bottom: 20px; border-radius: 5px; overflow: hidden; position: relative; }
        #scan-result { font-size: 18px; font-weight: bold; color: #007bff; }
        #unique-id-display { font-weight: bold; color: #007bff; padding: 10px; background: #f8f9fa; border-radius: 5px; margin-top: 10px; text-align: center; }
        .tab-content { padding: 20px 0; }
        .nav-tabs .nav-item { margin-bottom: -1px; }
        .nav-tabs .nav-link.active { background: linear-gradient(45deg, #007bff, #0056b3); color: white; border: none; border-radius: 5px 5px 0 0; }
        .nav-tabs .nav-link { border: 1px solid #dee2e6; border-radius: 5px 5px 0 0; margin-right: 5px; }
    </style>
</head>
<body>
    <div class="container-fluid py-4">
        <h1 class="text-center mb-4">Product Management System</h1>
        
        <ul class="nav nav-tabs" id="myTab" role="tablist">
            <li class="nav-item">
                <a class="nav-link active" id="products-tab" data-toggle="tab" href="#products" role="tab">Products</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" id="scanner-tab" data-toggle="tab" href="#scanner" role="tab">QR Scanner</a>
            </li>
        </ul>
        
        <div class="tab-content" id="myTabContent">
            <!-- Products Tab -->
            <div class="tab-pane fade show active" id="products" role="tabpanel">
                <div class="row">
                    <div class="col-md-4">
                        <div class="card">
                            <div class="card-header"><h3 class="text-center">Product Form</h3></div>
                            <div class="card-body">
                                <form action="" id="manage-product">
                                    <input type="hidden" name="id">
                                    <input type="hidden" name="product_id"> <!-- NEW HIDDEN FIELD -->
                                    
                                    <div class="form-group">
                                        <label>Category</label>
                                        <select name="category_id" id="category_id" class="custom-select select2" required>
                                            <option value=""></option>
                                            <?php
                                            $qry = $conn->query("SELECT * FROM categories ORDER BY name ASC");
                                            while($row=$qry->fetch_assoc()):
                                                $cname[$row['id']] = ucwords($row['name']);
                                            ?>
                                            <option value="<?php echo $row['id'] ?>"><?php echo $row['name'] ?></option>
                                            <?php endwhile; ?>
                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <label>Name</label>
                                        <input type="text" class="form-control" name="name" required>
                                    </div>
                                    <div class="form-group">
                                        <label>Description</label>
                                        <textarea name="description" cols="30" rows="3" class="form-control" required></textarea>
                                    </div>
                                    <div class="form-group">
                                        <label>Price</label>
                                        <input type="number" class="form-control text-right" name="price" required>
                                    </div>
                                    <div class="form-group">
                                        <div class="custom-control custom-switch">
                                            <input type="checkbox" class="custom-control-input" id="status" name="status" checked value="1" required>
                                            <label class="custom-control-label" for="status">Available</label>
                                        </div>
                                    </div>
                                    <div class="form-group text-center">
                                        <button type="submit" class="btn btn-primary btn-lg">Save Product</button>
                                        <button type="button" class="btn btn-default btn-lg" onclick="$('#manage-product').get(0).reset()">Cancel</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                        
                        <div class="card mt-4">
                            <div class="card-header"><h3 class="text-center">Product ID & QR Code</h3></div>
                            <div class="card-body text-center">
                                <div id="unique-id-display">No product ID generated yet</div>
                                <div id="qrcode" class="qrcode-container"></div>
                                <button class="btn btn-success mt-2" id="download-qr" disabled>Download QR Code</button>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-md-8">
                        <div class="card">
                            <div class="card-header"><h3 class="text-center">Product List</h3></div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table table-bordered table-hover" id="productTable">
                                        <thead>
                                            <tr>
                                                <th>ID</th>
                                                <th>Product ID</th> <!-- NEW COLUMN -->
                                                <th>Category</th>
                                                <th>Name</th>
                                                <th>Description</th>
                                                <th>Price</th>
                                                <th>Status</th>
                                                <th>QR Code</th>
                                                <th>Actions</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            $products = $conn->query("SELECT p.*, c.name as cname FROM products p INNER JOIN categories c ON c.id = p.category_id ORDER BY p.id DESC");
                                            while($row = $products->fetch_assoc()):
                                            ?>
                                            <tr>
                                                <td><?php echo $row['id'] ?></td>
                                                <td><?php echo $row['product_id'] ?></td>
                                                <td><?php echo $row['cname'] ?></td>
                                                <td><?php echo $row['name'] ?></td>
                                                <td><?php echo $row['description'] ?></td>
                                                <td><?php echo number_format($row['price'], 2) ?></td>
                                                <td>
                                                    <?php if($row['status'] == 1): ?>
                                                        <span class="badge badge-success">Available</span>
                                                    <?php else: ?>
                                                        <span class="badge badge-warning">Unavailable</span>
                                                    <?php endif; ?>
                                                </td>
                                                <td>
                                                    <button class="btn btn-sm btn-info view-qr" data-product_id="<?php echo $row['product_id'] ?>">View QR</button>
                                                </td>
                                                <td class="action-buttons">
                                                    <button class="btn btn-sm btn-primary edit_product" 
                                                        data-id="<?php echo $row['id'] ?>"
                                                        data-product_id="<?php echo $row['product_id'] ?>"
                                                        data-name="<?php echo $row['name'] ?>"
                                                        data-description="<?php echo $row['description'] ?>"
                                                        data-price="<?php echo $row['price'] ?>"
                                                        data-category_id="<?php echo $row['category_id'] ?>"
                                                        data-status="<?php echo $row['status'] ?>">Edit</button>
                                                    <button class="btn btn-sm btn-danger delete_product" data-id="<?php echo $row['id'] ?>">Delete</button>
                                                </td>
                                            </tr>
                                            <?php endwhile; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Scanner Tab -->
            <div class="tab-pane fade" id="scanner" role="tabpanel">
                <div class="row">
                    <div class="col-md-6">
                        <div class="card">
                            <div class="card-header"><h3 class="text-center">QR Code Scanner</h3></div>
                            <div class="card-body">
                                <div id="scanner-container">
                                    <p class="text-white text-center p-4">Scanner would appear here. For demonstration, use the test button.</p>
                                </div>
                                <div class="text-center">
                                    <button class="btn btn-success" id="test-scan">Test Scan (Simulate)</button>
                                </div>
                                <div class="mt-3">
                                    <h5>Scan Result:</h5>
                                    <div id="scan-result" class="p-2">No product scanned yet</div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="card">
                            <div class="card-header"><h3 class="text-center">Scan Instructions</h3></div>
                            <div class="card-body">
                                <ol>
                                    <li>Click "Test Scan" to simulate scanning a product QR code</li>
                                    <li>The system will automatically detect and decode the QR code</li>
                                    <li>Product details will be displayed below the scanner</li>
                                    <li>You can search for products by name or category in the Products tab</li>
                                </ol>
                                <div class="alert alert-info"><strong>Note:</strong> This is a demonstration. In a real application, you would use a camera to scan actual QR codes.</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- QR Code Modal -->
    <div class="modal fade" id="qrModal" tabindex="-1" role="dialog">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header"><h5 class="modal-title">Product QR Code</h5>
                    <button type="button" class="close" data-dismiss="modal"><span>&times;</span></button>
                </div>
                <div class="modal-body text-center">
                    <div id="modal-qrcode" class="qrcode-container"></div>
                    <p class="mt-3">Product ID: <span id="product-id-placeholder"></span></p>
                    <button class="btn btn-success mt-2" id="download-modal-qr">Download QR Code</button>
                </div>
            </div>
        </div>
    </div>

<script>
$(document).ready(function() {
    // Handle form submission
    $('#manage-product').submit(function(e){
        e.preventDefault();

        // Generate unique product_id if new product
        if (!$('input[name="id"]').val()) {
            const productId = 'PRD' + Math.floor(1000 + Math.random() * 9000);
            $('input[name="product_id"]').val(productId);

            $('#unique-id-display').text('Product ID: ' + productId);
            generateQRCode(productId, 'qrcode');
            $('#download-qr').prop('disabled', false);
        }

        $.ajax({
            url:'ajax.php?action=save_product',
            data: new FormData($(this)[0]),
            cache: false,
            contentType: false,
            processData: false,
            method: 'POST',
            success:function(resp){
             if(resp==1){
    $('#unique-id-display').html(`
        ✅ Product successfully added!<br>
        <button class="btn btn-success mt-2" id="print-product">Print Product</button>
        <button class="btn btn-secondary mt-2" id="cancel-product">Cancel</button>
    `);
    $('#download-qr').prop('disabled', false);
                } else if(resp==2){
                    alert("Data successfully updated");
                    setTimeout(()=> location.reload(), 1500);
                }
            }
        })
    });

    // View QR code
    $('.view-qr').click(function() {
        const productId = $(this).data('product_id');
        generateQRCode(productId, 'modal-qrcode');
        $('#product-id-placeholder').text(productId);
        $('#qrModal').modal('show');
    });

    // Edit product
    $('.edit_product').click(function(){
        var cat = $('#manage-product');
        cat.get(0).reset();
        cat.find("[name='id']").val($(this).data('id'));
        cat.find("[name='product_id']").val($(this).data('product_id'));
        cat.find("[name='name']").val($(this).data('name'));
        cat.find("[name='description']").val($(this).data('description'));
        cat.find("[name='price']").val($(this).data('price'));
        cat.find("[name='category_id']").val($(this).data('category_id')).trigger('change');
        if($(this).data('status') == 1) $('#status').prop('checked',true);
        else $('#status').prop('checked',false);

        $('#unique-id-display').text('Product ID: ' + $(this).data('product_id'));
        generateQRCode($(this).data('product_id'), 'qrcode');
        $('#download-qr').prop('disabled', false);
    });

    // Delete product
    $('.delete_product').click(function(){
        if(confirm("Are you sure to delete this product?")){
            $.ajax({
                url:'ajax.php?action=delete_product',
                method:'POST',
                data:{id:$(this).data('id')},
                success:function(resp){
                    if(resp==1){
                        alert("Data successfully deleted");
                        setTimeout(()=> location.reload(), 1500);
                    }
                }
            })
        }
    });

    // Test scan button
    $('#test-scan').click(function() {
        const sampleProducts = [
            <?php
            $products = $conn->query("SELECT product_id FROM products ORDER BY id DESC LIMIT 3");
            $ids = [];
            while($row = $products->fetch_assoc()) {
                $ids[] = $row['product_id'];
            }
            echo "'" . implode("','", $ids) . "'";
            ?>
        ];
        
        if (sampleProducts.length > 0) {
            const randomProduct = sampleProducts[Math.floor(Math.random() * sampleProducts.length)];
            
            $.ajax({
                url: 'ajax.php?action=get_product',
                method: 'POST',
                data: {product_id: randomProduct},
                success: function(resp) {
                    try {
                        const product = JSON.parse(resp);
                        $('#scan-result').html(`
                            Product scanned: <strong>${product.product_id}</strong><br>
                            Name: ${product.name}<br>
                            Category: ${product.cname}<br>
                            Price: $${product.price}<br>
                            Status: ${product.status == 1 ? 'Available' : 'Unavailable'}
                        `);
                    } catch(e) {
                        $('#scan-result').html('Error loading product details');
                    }
                }
            });
        } else {
            $('#scan-result').html('No products available for scanning');
        }
    });

    // Generate QR code
    function generateQRCode(productId, elementId) {
        $('#' + elementId).empty();
        new QRCode(document.getElementById(elementId), {
            text: productId.toString(),
            width: 200,
            height: 200,
            colorDark: "#000000",
            colorLight: "#ffffff",
            correctLevel: QRCode.CorrectLevel.H
        });

        if (elementId === 'qrcode') {
            $('#download-qr').off('click').on('click', function() {
                const canvas = document.querySelector("#qrcode canvas");
                const url = canvas.toDataURL("image/png");
                const link = document.createElement("a");
                link.download = `qrcode-${productId}.png`;
                link.href = url;
                link.click();
            });
        }
        if (elementId === 'modal-qrcode') {
            $('#download-modal-qr').off('click').on('click', function() {
                const canvas = document.querySelector("#modal-qrcode canvas");
                const url = canvas.toDataURL("image/png");
                const link = document.createElement("a");
                link.download = `qrcode-${productId}.png`;
                link.href = url;
                link.click();
            });
        }
    }
    // Handle Print Product
$(document).on('click', '#print-product', function() {
    let productId = $('input[name="product_id"]').val();

    let printWindow = window.open('', '', 'height=600,width=800');
    printWindow.document.write('<html><head><title>Print QR Code</title></head><body style="text-align:center;">');
    printWindow.document.write(document.getElementById("qrcode").innerHTML); // Sirf QR code
    printWindow.document.write('</body></html>');
    printWindow.document.close();
    printWindow.print();
});


});

document.addEventListener("DOMContentLoaded", function() {
    let mayuriFooter = document.querySelector("div div a[href*='mayurik']");
    if (mayuriFooter) {
        mayuriFooter.closest("div").style.display = "none";
    }
});
</script>
</body>
</html>
