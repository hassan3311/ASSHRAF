<?php
ob_start();
$action = $_GET['action'];
include 'admin_class.php';
$crud = new Action();
if($action == 'login'){
	$login = $crud->login();
	if($login)
		echo $login;
}
if($action == 'login2'){
	$login = $crud->login2();
	if($login)
		echo $login;
}
if($action == 'logout'){
	$logout = $crud->logout();
	if($logout)
		echo $logout;
}
if($action == 'logout2'){
	$logout = $crud->logout2();
	if($logout)
		echo $logout;
}
if($action == 'save_user'){
	$save = $crud->save_user();
	if($save)
		echo $save;
}
if($action == 'delete_user'){
	$save = $crud->delete_user();
	if($save)
		echo $save;
}
if($action == 'signup'){
	$save = $crud->signup();
	if($save)
		echo $save;
}
if($action == 'update_account'){
	$save = $crud->update_account();
	if($save)
		echo $save;
}
if($action == "save_settings"){
	$save = $crud->save_settings();
	if($save)
		echo $save;
}
if($action == "save_category"){
	$save = $crud->save_category();
	if($save)
		echo $save;
}
if($action == "delete_category"){
	$delete = $crud->delete_category();
	if($delete)
		echo $delete;
}
if($action == "save_product"){
	$save = $crud->save_product();
	if($save)
		echo $save;
}
if($action == "delete_product"){
	$delete = $crud->delete_product();
	if($delete)
		echo $delete;
}

if($action == "save_order"){
	$save = $crud->save_order();
	if($save)
		echo $save;
}
if($action == "delete_order"){
	$delete = $crud->delete_order();
	if($delete)
		echo $delete;
}

if($_GET['action'] == 'scan_product'){
    $product_id = $_POST['product_id'];
    $qry = $conn->query("SELECT * FROM products WHERE product_id = '$product_id'");
    if($qry->num_rows > 0){
        $row = $qry->fetch_assoc();

        // Check if product already exists in bill, then increase qty
        $check = $conn->query("SELECT * FROM bill_items WHERE product_id = '$product_id'");
        if($check->num_rows > 0){
            $conn->query("UPDATE bill_items SET qty = qty+1, total = price*qty WHERE product_id = '$product_id'");
        } else {
            $conn->query("INSERT INTO bill_items (product_id, name, price, qty, total) 
                          VALUES ('".$row['product_id']."', '".$row['name']."', '".$row['price']."', 1, '".$row['price']."')");
        }

        echo 1; // success
    } else {
        echo 0; // not found
    }
    exit;
}
if($_GET['action'] == 'load_bill'){
    $qry = $conn->query("SELECT * FROM bill_items");
    echo "<table class='table table-bordered'>
            <tr><th>Product</th><th>Qty</th><th>Price</th><th>Total</th></tr>";
    while($row = $qry->fetch_assoc()){
        echo "<tr>
                <td>".$row['name']."</td>
                <td>".$row['qty']."</td>
                <td>".$row['price']."</td>
                <td>".$row['total']."</td>
              </tr>";
    }
    echo "</table>";
    exit;
}

if($_GET['action'] == 'get_product_by_code'){
    $code = $_POST['code'];
    $qry = $conn->query("SELECT * FROM products WHERE product_id = '$code' OR name = '$code'");
    if($qry->num_rows > 0){
        $row = $qry->fetch_assoc();
        echo json_encode(['status'=>1, 'product'=>$row]);
    } else {
        echo json_encode(['status'=>0]);
    }
    exit;
}


ob_end_flush();
?>
